<html>
	<head>
		<title>Мой альбом</title>
		<meta charset="utf-8" />
	
	</head>
	<body>
		<h1>Привет</h1>
		<?php
            $now = date("H:i:s");
            echo("<h2>Страница открыта в $now</h2>");
        ?>
	</body>
</html>